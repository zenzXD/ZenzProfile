def app():
    return 'Halo dari endpoint /zenz'